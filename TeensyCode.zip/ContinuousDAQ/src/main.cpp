#include <Arduino.h>
#include <ADC.h>

bool writing = 0;

bool clk = 0;
const int readPin = 18;
int val;
elapsedMicros timer1; 

// ADC vals
ADC *adc = new ADC();
int averages = 4;
int resolution = 12;
float mult;

// Buffer declaration
#define BUFFER_SIZE (1L << 8)
uint16_t buffer[BUFFER_SIZE];
uint8_t buffer_count = BUFFER_SIZE;



void setup() {
  Serial.begin(1152000);
  
  pinMode(18, INPUT); // Read pin
  pinMode(10, OUTPUT); // speed clocking

  // ADC fast setup
  adc->adc0->setAveraging(averages);
  adc->adc0->setResolution(resolution);
  adc->adc0->setConversionSpeed(ADC_CONVERSION_SPEED::HIGH_SPEED);
  adc->adc0->setSamplingSpeed(ADC_SAMPLING_SPEED::VERY_HIGH_SPEED);
  adc->adc0->startContinuous(readPin);

  // mult = 3.3/adc->adc0->getMaxValue();
  mult = 33000.0/adc->adc0->getMaxValue();
  // Previously was dividing this by averages bc my results were off. strange, don't need to anymore
}

// Max is 3.3 V, but so we get all resolution in 4 digits
long now;

void loop() {
  // if (Serial.available()){
  //   while(Serial.available()){
  //     Serial.read();
  //   }
  //   writing = !writing;
  //   if (!writing){
  //     Serial.write(0xF);
  //   }
  // }

  //   // Once a second, send a byte
  //   if (millis()-now > 500 && writing){
  //     now = millis();
  //     int yea = 2400;
  //     Serial.write(yea);
  //   } 
      



    


  if (Serial.available()){
    while(Serial.available()){
      Serial.read();
    }
    writing = !writing;
    // if (!writing){
    //   Serial.write(0xFF);
    // }

    clk = 0;
    digitalWriteFast(10,clk);
  }
    // Keep adding until overflow. Then we know the buffer is full
    // while (buffer_count){ 
      if (adc->adc0->isComplete() && writing){
        val = (uint16_t)adc->adc0->analogReadContinuous();
        // Serial.write(val);
        Serial.println(val);

        digitalWriteFast(10,!clk);
        clk = !clk;
      }
}
